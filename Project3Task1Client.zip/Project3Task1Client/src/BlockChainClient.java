//Emmanuel Gama Ibarra
//Andrew ID: egama

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigInteger;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;

import java.util.Random;
import java.util.Scanner;
/*
This class is a TCP server that allows the user store multiple ID and its respective values
It also allows the user to update its values and retrieve the actual values.
We are using TCP because we want to make sure that the information we send arrives in the correct order
The downside of using TCP is that its slower than UD
 */

public class BlockChainClient {
    /*I will have a Socket for this class, also the reader and writer will be class variables
    this is so I can create it only once. I spoke with professor and said it was the best practice
    */
    //Socket, in and out will be global variables so that every method can access it, these variables take care of the communication
    static Socket clientSocket = null;
    static Scanner in;
    static PrintWriter out;
    //For the encription keys
    static BigInteger n; // n is the modulus for both the private and public keys
    static BigInteger e; // e is the exponent of the public key
    static BigInteger d; // d is the exponent of the private key
    static String id;

    public static void main(String args[]) {
        boolean flag = true;
        init(); // After I initialized my client is running
        // I will use a forever loop that only exits if the user ask to exit
        createID();
        boolean first_time = true;
        Scanner input = new Scanner(System.in); //We will use this scanner many times
        while (true){ //infinite loop
            System.out.println( //Print the menu
                    "\nBlock Chain Menu \n0. View basic blockchain status. \n1. Add a transaction to the blockchain. " +
                            "\n2. Verify the blockchain. \n3. View the blockchain. \n4. Corrupt the chain. " +
                            "\n5. Hide the corruption by repairing the chain. \n6. Exit.");
            String option = input.next(); //Get the option
            switch (option) { //Switch statement for the option chosen
                case "0": //View basic status
                    getInfo("status");
                    break;
                case "1": //Add a transaction to the blockchain
                    System.out.println("Enter difficulty > 0");
                    int temp_dif = input.nextInt();
                    input.nextLine();
                    System.out.println("Enter transaction:");
                    String temp_data = input.nextLine();
                    postBlock(temp_dif, temp_data);
                    break;
                case "2": //Verify the blockchain
                    System.out.println("Verifying chain");
                    //System.out.println("Chain verification: " + valid ); //is it valid?
                    getInfo("verify");
                    break;
                case "3": //view the blockchain
                    getInfo("view");
                    break;
                case "4": //Corrupt the chain
                    System.out.println("Corrupt the Blockchain \nEnter block ID of block to Corrupt:");
                    int to_corrupt = input.nextInt();
                    System.out.println("Enter new data for block no. " + to_corrupt);
                    input.nextLine();
                    String corrupted_string = input.nextLine();
                    postCorruption(to_corrupt, corrupted_string);
                    break;
                case "5": // Fix the chain
                    System.out.println("Repairing the entire chain ");
                    postRepair();
                    break;
                case "6": //Exit the program
                    System.out.println("Exiting");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please enter a valid option");
            }
        }
    }

    static public void postBlock(int difficulty, String transaction ){
        JSONObject blockJson = new JSONObject();
        String message = null; 
        try {
            blockJson.put("operation", "postBlock");
            blockJson.put("difficulty", difficulty);
            blockJson.put("Tx", transaction);
            message = blockJson.toString(4);
            JSONObject rj = new JSONObject(send(message));
            System.out.println("Total execution time to add this block was " + rj.get("executionTime") + " milliseconds");
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
    }

    static public void getInfo(String operation){
        JSONObject blockJson = new JSONObject();
        String message = null;
        try {
            blockJson.put("operation", operation);
            blockJson.put("difficulty", 0);
            blockJson.put("Tx", 0);
            message = blockJson.toString(4);
            JSONObject rj = new JSONObject(send(message));
            if(operation.equals("verify")){
                System.out.println("Chain verification " + rj.get("verification"));
                System.out.println(rj.get("diagnostic").toString());
            } else if (operation.equals("status")) {
                System.out.println("This is the basic information of the blockchain\n" + rj.toString(4));
            } else if (operation.equals("view")){
                System.out.println("View the BlockChain \n" + rj.toString(4));
            }
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
    }


    static public void postCorruption(int index, String new_transaction){
        JSONObject blockJson = new JSONObject();
        String message = null;
        try {
            blockJson.put("operation", "postCorruption");
            blockJson.put("index", index);
            blockJson.put("Tx", new_transaction);
            message = blockJson.toString();
            JSONObject rj = new JSONObject(send(message));
            System.out.println("Chain verification " + rj.get("update"));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

    }

    static public void postRepair(){
        JSONObject blockJson = new JSONObject();
        String message = null;
        try {
            blockJson.put("operation", "repairChain");
            blockJson.put("difficulty", 0);
            blockJson.put("Tx", 0);
            message = blockJson.toString(4);
            JSONObject rj = new JSONObject(send(message));
            System.out.println("Total execution time to add this block was " + rj.get("executionTime") + " milliseconds");
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        send(message);
    }

    /*
    The proxy method is the one in charge of comunicating with the server
    It takes the socket that has been already created so that I don't have to create it multiple times
     */
    private static String send(String message) {
        // First concatenate all the information I receive
        JSONObject json_to_sign = new JSONObject(); //To send message put everything into a json
        try {
            JSONObject json_message = new JSONObject(message);
            json_to_sign.put("id", id);
            json_to_sign.put("message", json_message);
            json_to_sign.put("e", e);
            json_to_sign.put("n", n.toString());
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        //String message_to_sign = id + "," + message + "," + e + "," + n;
        //Sign the package
        String signiature = sign(json_to_sign.toString()); //sign

        //String final_message = message_to_sign + "," + signiature;
        JSONObject final_json = null;
        try {
            final_json = new JSONObject();
            final_json.put("signiature", signiature);
            final_json.put("information", json_to_sign);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        //I send the message
        try {
            out.println(final_json.toString(4 ));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }
        out.flush();
        //Then I receive the response
        String response = in.nextLine();
        try {
            JSONObject json_response = new JSONObject(response);
            //System.out.println("Response from Server: "+ json_response.toString(4));
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        return response;
    }


    private static String sign (String data){
        byte [] messageDigest = null; // This is the digest I will use
        BigInteger c = null;
        try {
            //bytesOfMessage = hexStringToByteArray("00"+ hex_data); //Add 00 so it is not negative
            MessageDigest md = MessageDigest.getInstance("SHA-256"); // hash
            messageDigest = md.digest(data.getBytes()); // Digest, this is the actual hash of the data
            byte [] newArray = new byte[messageDigest.length+1];
            newArray[0] = 0;
            for (int i = 0; i < messageDigest.length; i++) {
                newArray[i+1] = messageDigest[i];
            }
            //From the digest, create a big integer
            BigInteger m = new BigInteger(newArray); // Create the integer

            //Encript the digest with the private key
            c = m.modPow(d, n);
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }

        return c.toString();
    }


    private static void createKeys(){
        Random rnd = new Random();
        BigInteger p = new BigInteger(2048,100,rnd);
        BigInteger q = new BigInteger(2048,100,rnd);
        //Compute n
        n = p.multiply(q);
        //Compute phi
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        //Compute e, a small odd integer relative prime to phi
        e = new BigInteger ("65537"); //Chose by convention
        d = e.modInverse(phi); //This is the private key

        System.out.println(" e = " + e);  // Step 6: (e,n) is the RSA public key
        System.out.println(" d = " + d);  // Step 7: (d,n) is the RSA private key
        System.out.println(" n = " + n);  // Modulus for both keys

    }

    public static void createID(){
        String public_key_concat = e.toString().concat(n.toString());
        String hash = ComputeSHA_256_as_Hex_String(public_key_concat);
        // take the las 40, because 2 hex digits equal 1 byte
        id = hash.substring(hash.length()-40); //This is the string to be signed, this is because the hash is a representation of

    }

    //This code was taken from the class notes
    private static String ComputeSHA_256_as_Hex_String(String text){
        try{
            //Create digest of 256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            //Perform the hash
            digest.update(text.getBytes("UTF-8"), 0, text.length());
            //Put the hash in a byte array
            byte [] hashBytes = digest.digest();
            //Return the hex representation
            return convertToHex(hashBytes);

        } catch (NoSuchAlgorithmException nsa) {
            System.out.println("No such algorithm exception thrown " + nsa);
        } catch (UnsupportedEncodingException uee) {
            System.out.println("Unsupported encoding exception thrown " + uee);
        }
        return null;
    }
    // code from Stack overflow
    // converts a byte array to a string.
    // each nibble (4 bits) of the byte array is represented
    // by a hex characer (0,1,2,3,...,9,a,b,c,d,e,f)
    private static String convertToHex(byte[] data){
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            int halfbyte = (data[i] >>> 4) & 0x0F;
            int two_halfs = 0;
            do{
                if ((0 <= halfbyte) && (halfbyte <= 9)){
                    buf.append((char)('0' + halfbyte));
                } else{
                    buf.append((char)('a' + (halfbyte - 10)));
                    halfbyte = data[i] & 0x0F;
                }
            } while (two_halfs++ < 1);
        } return buf.toString();
    }

    /*
The init method is to initialize the proxy, it uses the class variables and fills them
 */
    private static void init () {
        try {
            int serverPort = 7777; //This is the port I use
            clientSocket = new Socket("localhost", serverPort); //I use the localhost
            System.out.println("Client running"); //Now the client is running
            in = new Scanner(clientSocket.getInputStream());
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))); //To receive messages
            //Catch multiple type of exceptions
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        createKeys();

    }

    //getter method for time
    public static Timestamp getTime(){
        return new Timestamp(System.currentTimeMillis());
    }




}