//Emmanuel Gama Ibarra
//Andrew id: egama
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;


/**
 * Block class
 * This class created blocks for the block chain
 *
 * Class methods:
 * Constructor, main(), calculateHash(), getData(), getDifficulty(), getIndex(), getNonce()
 * getPreviousHash(), getPreviousHash(), getTimeStamp(), proofOfWork(), setData, setDifficulty, setIndex, setPreviousHash,
 * setTimestamp
 * Methods inherited from class java.lang.Object :clone, equals, finalize, getClass, hashCode, notify, notifyAll, wait, wait, wait
 * Each Block object has an index - the position of the block on the chain. The first block (the so called Genesis block) has an index of 0.
 * Each block has a timestamp - a Java Timestamp object, it holds the time of the block's creation.
 * Each block has a field named data - a String holding the block's single transaction details.
 * Each block has a String field named previousHash - the SHA256 hash of a block's parent. This is also called a hash pointer.
 */
public class Block {

    int index;
    Timestamp timestamp;
     String data;
    int difficulty;
     BigInteger  nonce = BigInteger.ZERO;
     String previousHash = null;

    Block (int index, Timestamp timestamp, String data, int difficulty){
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
    }

    static public void main (String[] args){

    }

    /*
This method computes a hash of the concatenation of the index, timestamp, data, previousHash, nonce, and difficulty.
*/
    public String calculateHash(){
        String textToHash = this.index + this.timestamp.toString() + this.data + this.previousHash + this.nonce.toString() + this.difficulty;
        StringBuffer hexString = new StringBuffer();
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytesToHash = md.digest(textToHash.getBytes("UTF-8"));
            for (int i = 0; i < bytesToHash.length; i++) {
                String hex = Integer.toHexString(0xff & bytesToHash[i]);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        return hexString.toString();
    }
/*
The proof of work methods finds a good hash. It increments the nonce until it produces a good hash.
This method calls calculateHash() to compute a hash of the concatenation of the index, timestamp,
data, previousHash, nonce, and difficulty. If the hash has the appropriate number of leading hex zeroes,
it is done and returns that proper hash. If the hash does not have the appropriate number of leading hex zeroes,
it increments the nonce by 1 and tries again. It continues this process, burning electricity and CPU cycles,
until it gets lucky and finds a good hash.

Returns: a String with a hash that has the appropriate number of leading hex zeroes.
The difficulty value is already in the block. This is the number of hex 0's a proper hash must have.
 */

    public String proofOfWork(){
        boolean keep_looking = true;
        String tempHash = null;
        while (keep_looking){ // Infinite look until we find the right number of zeros in the hash
            tempHash = calculateHash(); //Helper method to calculate a hash with the given info
            char[] hashArray = tempHash.toCharArray(); //Change that hash to a char array
            boolean all_zeros = true; // everytime, we create this boolean
            for (int i = 0; i < difficulty; i++) { //for all chars up to the difficulty level
                if(Character.toString(hashArray[i]).equals("0")){ //If char i equals 0
                    //All good, do nothing
                } else {
                    all_zeros = false; // If only one is missing, all zeros is false
                    this.nonce = this.nonce.add(BigInteger.ONE); //Increase the nonce
                }
            }
            if (all_zeros == true){ //If all zeros is true, then we stop looking
                keep_looking = false;
            }
        }
        return tempHash; //Return the created hash
    }

    /*
This method returns the nonce for this block.
The nonce is a number that has been found to cause
the hash of this block to have the correct number of leading hexadecimal zeroes.
 */
    public BigInteger getNonce(){
        return this.nonce;
    }
    // Simple getter method to get the message of the transaction
    public String getData(){
        return this.data;
    }
    // Simple getter method to get the difficulty level of the block
    public int getDifficulty(){
        return this.difficulty;
    }
    // Simple getter method to get the index  of the block
    public int getIndex(){
        return this.index;
    }
    // Simple getter method to get the previous hash of the block
    public String getPreviousHash(){
        return this.previousHash;
    }
    //Simple getter method to get the timestamp of the block
    public Timestamp getTimeStamp(){
        return this.timestamp;
    }
    //Simple setter method
    public void setData(String data){
        this.data = data;
    }

    //Simple setter method
    public void setDifficulty(int difficulty){
        this.difficulty = difficulty;
    }
    //Simple setter method
    public void setIndex(int index){
        this.index = index;
    }
    //Simple setter method
    public void setPreviousHash(String previousHash){
        this.previousHash = previousHash;
    }
    //Simple setter method
    public void setTimestamp(Timestamp timestamp){
        this.timestamp = timestamp;
    }

    @Override //Converts this block into a string representation
    public String toString(){
        JSONObject blockJson = new JSONObject(); //I create this json object and then I put the info into it
        try { //Add all the info I want
            blockJson.put("index", this.getIndex());
            blockJson.put("timestamp", this.getTimeStamp());
            blockJson.put("Tx", this.getData());
            blockJson.put("PrevHash", this.getPreviousHash());
            blockJson.put("nonce", this.getNonce());
            blockJson.put("difficulty", this.getDifficulty());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            return blockJson.toString(4); //This is for pretty printing
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return blockJson.toString();
    }

    // code from Stack overflow
    // converts a byte array to a string.
    // each nibble (4 bits) of the byte array is represented
    // by a hex characer (0,1,2,3,...,9,a,b,c,d,e,f)
    private static String convertToHex(byte[] data){
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            int halfbyte = (data[i] >>> 4) & 0x0F;
            int two_halfs = 0;
            do{
                if ((0 <= halfbyte) && (halfbyte <= 9)){
                    buf.append((char)('0' + halfbyte));
                } else{
                    buf.append((char)('a' + (halfbyte - 10)));
                    halfbyte = data[i] & 0x0F;
                }
            } while (two_halfs++ < 1);
        } return buf.toString();
    }


}
